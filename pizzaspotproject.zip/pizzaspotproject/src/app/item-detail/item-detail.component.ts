import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {Router} from '@angular/router';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-item-detail',
  templateUrl: './item-detail.component.html',
  styleUrls: ['./item-detail.component.css']
})
export class ItemDetailComponent {

  public itemId:any;
  public itemName:any;
  public category:any;
  public size:any;
  public price:any;
  public crust:any;
  public discount:any;
  public image:any;
  public vn:any;

  public Data:any;
  constructor(private route:ActivatedRoute,private router:Router,private api:ApiService){}
  ngOnInit(){

    let id = this.route.snapshot.paramMap.get('id');
    this.itemId = id;
    let name = this.route.snapshot.paramMap.get('name');
    this.itemName = name;
    let category = this.route.snapshot.paramMap.get('category');
    this.category = category;
    let size = this.route.snapshot.paramMap.get('size');
    this.size = size;
    let crust = this.route.snapshot.paramMap.get('crust');
    this.crust = crust;
    let price = this.route.snapshot.paramMap.get('price');
    this.price = price;
    let discount = this.route.snapshot.paramMap.get('discount');
    this.discount = discount;
    let image = this.route.snapshot.paramMap.get('image');
    this.image = image;
    let vn = this.route.snapshot.paramMap.get('vn');
    this.vn= vn;

  }

  addToCart(id:any){
    
    
    this.router.navigate(['cart',id]);
  }

  backToHome(){
    this.router.navigate(['item'])
  }
}
