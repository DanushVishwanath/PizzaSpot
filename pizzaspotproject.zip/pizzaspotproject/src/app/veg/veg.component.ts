import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-veg',
  templateUrl: './veg.component.html',
  styleUrls: ['./veg.component.css']
})
export class VegComponent {

  itemData: any;
  vegArray: any = [];
  constructor(private api: ApiService, private router:Router) { }

  ngOnInit() {
    this.api.getAllItems().subscribe(
      res => {
        this.itemData = res;
        console.log(this.itemData.length);

        for (let i = 0; i < this.itemData.length; i++) {


          if (this.itemData[i].category === 'veg-pizza') {

            this.vegArray.push(this.itemData[i]);
          }
        }

      }
    );


  }

  fetchItem(item:any){
    this.router.navigate(['/itemDetail',item.id,item.name,item.category,item.size,item.crust,item.price,item.discount,item.image,item.vn]);
  }

  addToCart(id:any){
    
    
    this.router.navigate(['cart',id]);
  }


}
