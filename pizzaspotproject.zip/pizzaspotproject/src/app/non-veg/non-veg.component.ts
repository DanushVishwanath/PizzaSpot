import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-non-veg',
  templateUrl: './non-veg.component.html',
  styleUrls: ['./non-veg.component.css']
})
export class NonVegComponent {
  itemData: any;
  nonVegArray: any = [];
  constructor(private api: ApiService, private router: Router) { }

  ngOnInit() {
    this.api.getAllItems().subscribe(
      res => {
        this.itemData = res;
        console.log(this.itemData.length);

        for (let i = 0; i < this.itemData.length; i++) {


          if (this.itemData[i].category === 'non-veg-pizza') {

            this.nonVegArray.push(this.itemData[i]);
          }
        }

      }
    );


  }

  fetchItem(item:any){
    this.router.navigate(['/itemDetail',item.id,item.name,item.category,item.size,item.crust,item.price,item.discount,item.image,item.vn]);
  }

  addToCart(id:any){
    
    
    this.router.navigate(['cart',id]);
  }
}
