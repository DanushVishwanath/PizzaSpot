import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-beverages',
  templateUrl: './beverages.component.html',
  styleUrls: ['./beverages.component.css']
})
export class BeveragesComponent {

  itemData: any;
  beverageArray: any = [];
  constructor(private api: ApiService, private router:Router) { }

  ngOnInit() {
    this.api.getAllItems().subscribe(
      res => {
        this.itemData = res;
        console.log(this.itemData.length);

        for (let i = 0; i < this.itemData.length; i++) {


          if (this.itemData[i].category === 'beverages') {

            this.beverageArray.push(this.itemData[i]);
          }
        }

      }
    );


  }

  fetchItem(item:any){
    this.router.navigate(['/itemDetail',item.id,item.name,item.category,item.size,item.crust,item.price,item.discount,item.image,item.vn]);
  }

  addToCart(id:any){
    
    
    this.router.navigate(['cart',id]);
  }
}
