import { Component } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css'],
  providers: [ApiService]
})
export class ItemComponent {

  itemData:any;

   constructor(private api: ApiService,
              private router:Router,
              private http:HttpClient) {}

  ngOnInit(){
    this.getAllItems();
  }
  getAllItems(){
    this.api.getAllItems().subscribe(
      res=>{
        this.itemData=res;
      }
    );
  }

  fetchItem(item:any){
    this.router.navigate(['/itemDetail',item.id,item.name,item.category,item.size,item.crust,item.price,item.discount,item.image,item.vn]);
  }

  addToCart(id:any){
    
    
    this.router.navigate(['cart',id]);
  }
}
