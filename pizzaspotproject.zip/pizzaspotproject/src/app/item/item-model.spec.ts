import { ItemModel } from './item-model';

describe('ItemModel', () => {
  it('should create an instance', () => {
    expect(new ItemModel()).toBeTruthy();
  });
});
