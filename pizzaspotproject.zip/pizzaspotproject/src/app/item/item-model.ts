export class ItemModel {
    id:number=0;
    name:string='';
    category:string='';
    size:string='';
    crust:string='';
    price:number=0;
    discount:string='';
    image:string='';
    vn:string='';
}
