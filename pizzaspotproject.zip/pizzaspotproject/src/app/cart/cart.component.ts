import { Component } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { ItemModel } from '../item/item-model';
import { ApiService } from '../services/api.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {

  itemId:any;
  ItemObj:any;
  itemArray:any=[];
  arr:any;
  grandTotal:number=0;

  constructor(private route:ActivatedRoute, private api:ApiService){}

  ngOnInit(){
    this.itemId=this.route.snapshot.paramMap.get('id');
    this.api.getItemById(this.itemId).subscribe(
      res=>{
        console.log(res);
        this.api.saveToArray(res);
        this.calculateTotal();
      }
    );
    this.calculateTotal();
    this.getAllCartItems();
     
  }

  getAllCartItems(){

    this.itemArray= this.api.getAllCartItems()
    this.calculateTotal();

    
  }

  calculateTotal(){
    this.grandTotal=0;
    for(let product of this.itemArray){
      this.grandTotal+=(product.price);
      this.grandTotal=Math.floor(this.grandTotal);
    }
  }

  removeFromCart(item:any){
    this.api.deleteFromCart(item.id);
    this.calculateTotal();
    this.getAllCartItems();
    
  }
}
