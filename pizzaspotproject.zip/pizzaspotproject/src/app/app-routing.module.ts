import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { BeveragesComponent } from './beverages/beverages.component';
import { CartComponent } from './cart/cart.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { ItemDetailComponent } from './item-detail/item-detail.component';
import { ItemComponent } from './item/item.component';
import { NonVegComponent } from './non-veg/non-veg.component';
import { VegComponent } from './veg/veg.component';

const routes: Routes = [
  {path:'',redirectTo:'/item',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'item',component:ItemComponent},
  {path:'about',component:AboutUsComponent},
  {path:'contact',component:ContactUsComponent},
  {path:'cart',component:CartComponent},
  {path:'cart/:id',component:CartComponent},
  {path:'veg',component:VegComponent},
  {path:'nonveg',component:NonVegComponent},
  {path:'beverages',component:BeveragesComponent},
  {path:'itemDetail/:id/:name/:category/:size/:crust/:price/:discount/:image/:vn',component:ItemDetailComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
