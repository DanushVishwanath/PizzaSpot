import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  cartArray:any=[];
  vegArray:any=[];
  constructor(private httpClient: HttpClient) { }

  getAllItems(){
    return this.httpClient.get<any>("http://localhost:3000/posts").pipe(
      map((response:any)=>{
        return response;
      }
    )
    );
  }

  getItemById(id:any){
    return this.httpClient.get<any>("http://localhost:3000/posts/"+id).pipe(
      map((response:any)=>{
        
        return response;
      }
    )
    );
  }

  saveToArray(data:any){
    this.cartArray.push(data);
    
    
  }
  getAllCartItems(){
    return this.cartArray;
  }

  deleteFromCart(data:any){
    for(let i=0;i<(this.cartArray).length;i++){
      if((this.cartArray[i]).id==data){
        (this.cartArray).splice(i,1);
        break;
      }
    }
  }

  // getVegpizzas(){
  //   this.httpClient.get<any>("http://localhost:3000/posts").pipe(
  //     map((response:any)=>{
  //       this.vegArray.push(response);
  //     }
  //   )
  //   );
  //   return this.vegArray;
  // }
}
